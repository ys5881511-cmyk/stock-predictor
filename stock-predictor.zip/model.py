import yfinance as yf
import pandas as pd
from sklearn.ensemble import RandomForestClassifier

def fetch_data(symbol: str, period: str = "6mo", interval: str = "1d") -> pd.DataFrame:
    """Download historical OHLC data from Yahoo Finance."""
    df = yf.download(symbol, period=period, interval=interval, auto_adjust=False)
    df = df.reset_index()
    return df

def add_features(df: pd.DataFrame) -> pd.DataFrame:
    """Create ML features from price series."""
    df["Return"] = df["Close"].pct_change()
    df["MA_5"] = df["Close"].rolling(5).mean()
    df["MA_10"] = df["Close"].rolling(10).mean()
    df["Volatility"] = df["Return"].rolling(10).std()

    # Target: 1 if next-day close > today close else 0
    df["Target"] = (df["Close"].shift(-1) > df["Close"]).astype(int)
    df = df.dropna()
    return df

def ml_predict_direction(symbol: str) -> str:
    """Train a simple RandomForest and predict next-day direction."""
    df = fetch_data(symbol, period="1y", interval="1d")
    if df.empty or len(df) < 40:
        return "NOT_ENOUGH_DATA"

    df = add_features(df)
    if len(df) < 40:
        return "NOT_ENOUGH_DATA"

    feature_cols = ["Return", "MA_5", "MA_10", "Volatility"]
    X = df[feature_cols]
    y = df["Target"]

    # Train on all but last row
    model = RandomForestClassifier(n_estimators=120, random_state=42)
    model.fit(X.iloc[:-1], y.iloc[:-1])

    last_features = X.iloc[[-1]]
    pred = model.predict(last_features)[0]
    return "UP" if pred == 1 else "DOWN"

def trend_predict(df: pd.DataFrame) -> str:
    """Simple SMA 20/50 crossover prediction."""
    if len(df) < 60:
        return "NOT_ENOUGH_DATA"

    df = df.copy()
    df["SMA_20"] = df["Close"].rolling(20).mean()
    df["SMA_50"] = df["Close"].rolling(50).mean()

    last_20 = df["SMA_20"].iloc[-1]
    last_50 = df["SMA_50"].iloc[-1]

    if pd.isna(last_20) or pd.isna(last_50):
        return "NOT_ENOUGH_DATA"

    return "UP" if last_20 > last_50 else "DOWN"
