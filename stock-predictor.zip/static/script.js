// Popular symbols for autocomplete
const popularSymbols = [
    "RELIANCE.NS", "TCS.NS", "INFY.NS", "HDFCBANK.NS", "ICICIBANK.NS",
    "SBIN.NS", "AXISBANK.NS", "KOTAKBANK.NS", "ITC.NS", "HINDUNILVR.NS",
    "AAPL", "MSFT", "GOOGL", "AMZN", "TSLA", "META", "NFLX"
];

let liveInterval = null;
let currentSymbol = null;

const form = document.getElementById("predictForm");
const symbolInput = document.getElementById("symbolInput");
const suggestionsDiv = document.getElementById("suggestions");
const loader = document.getElementById("loader");
const alertBox = document.getElementById("alertBox");
const chartDiv = document.getElementById("chart");

const liveSymbol = document.getElementById("liveSymbol");
const livePrice = document.getElementById("livePrice");
const liveChange = document.getElementById("liveChange");
const trendResult = document.getElementById("trendResult");
const mlResult = document.getElementById("mlResult");

// Show alert
function showAlert(msg) {
    alertBox.innerText = msg;
    alertBox.style.display = "block";
    setTimeout(() => {
        alertBox.style.display = "none";
    }, 3000);
}

// Render candlestick chart using Plotly
function renderChart(chart) {
    const trace = {
        x: chart.dates,
        open: chart.open,
        high: chart.high,
        low: chart.low,
        close: chart.close,
        type: "candlestick",
        increasing: { line: { color: "#26a69a" } },
        decreasing: { line: { color: "#ef5350" } }
    };

    const layout = {
        dragmode: "zoom",
        margin: { r: 10, t: 25, b: 40, l: 40 },
        paper_bgcolor: "rgba(0,0,0,0)",
        plot_bgcolor: "rgba(0,0,0,0)",
        xaxis: { title: "Date" },
        yaxis: { title: "Price" }
    };

    Plotly.newPlot(chartDiv, [trace], layout, { responsive: true });
}

// Autocomplete suggestions
symbolInput.addEventListener("input", () => {
    const text = symbolInput.value.toUpperCase();
    const container = document.createElement("div");
    container.className = "suggestions-list";

    if (!text) {
        suggestionsDiv.innerHTML = "";
        return;
    }

    const matches = popularSymbols.filter(s => s.includes(text)).slice(0, 5);
    if (matches.length === 0) {
        suggestionsDiv.innerHTML = "";
        return;
    }

    matches.forEach(m => {
        const item = document.createElement("div");
        item.className = "suggestion-item";
        item.innerText = m;
        item.onclick = () => {
            symbolInput.value = m;
            suggestionsDiv.innerHTML = "";
        };
        container.appendChild(item);
    });

    suggestionsDiv.innerHTML = "";
    suggestionsDiv.appendChild(container);
});

// Handle form submit
form.addEventListener("submit", async (e) => {
    e.preventDefault();
    const symbol = symbolInput.value.trim();

    if (!symbol) {
        showAlert("Please enter a stock symbol.");
        return;
    }

    loader.style.display = "block";
    chartDiv.innerHTML = "";
    trendResult.innerText = "Trend (SMA): --";
    mlResult.innerText = "ML Prediction: --";

    try {
        const response = await fetch("/predict", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ symbol: symbol })
        });

        const data = await response.json();
        loader.style.display = "none";

        if (data.error) {
            showAlert(data.error);
            return;
        }

        currentSymbol = data.symbol;
        liveSymbol.innerText = data.symbol;
        livePrice.innerText = "₹ " + data.latest_price;
        liveChange.innerText = `${data.change} (${data.change_pct}%)`;
        liveChange.style.color = data.change >= 0 ? "#4cd137" : "#e84118";

        trendResult.innerText = "Trend (SMA): " + data.trend_prediction;
        mlResult.innerText = "ML Prediction: " + data.ml_prediction;

        renderChart(data.chart);

        // Start live updates
        if (liveInterval) clearInterval(liveInterval);
        liveInterval = setInterval(fetchLivePrice, 5000);

    } catch (err) {
        loader.style.display = "none";
        showAlert("Error fetching prediction. Try again.");
    }
});

async function fetchLivePrice() {
    if (!currentSymbol) return;

    try {
        const response = await fetch("/price", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ symbol: currentSymbol })
        });

        const data = await response.json();

        if (data.error) {
            return;
        }

        livePrice.innerText = "₹ " + data.latest_price;
        liveChange.innerText = `${data.change} (${data.change_pct}%)`;
        liveChange.style.color = data.change >= 0 ? "#4cd137" : "#e84118";

    } catch (err) {
        // ignore errors for live polling
    }
}
