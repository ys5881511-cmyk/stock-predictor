from flask import Flask, render_template, request, jsonify
from model import fetch_data, trend_predict, ml_predict_direction
import pandas as pd

app = Flask(__name__)


@app.route("/")
def home():
    return render_template("index.html")


@app.route("/predict", methods=["POST"])
def predict():
    """Main endpoint: ML + Trend + Chart + Live Price"""

    data = request.get_json()
    symbol = data.get("symbol", "").strip()

    if not symbol:
        return jsonify({"error": "No symbol provided"}), 400

    # Fetch last 6 months daily data
    df = fetch_data(symbol, period="6mo", interval="1d")
    if df is None or df.empty:
        return jsonify({"error": "Could not fetch data"}), 400

    # 1. Trend prediction (SMA crossover)
    trend = trend_predict(df.copy())

    # 2. ML prediction
    ml_dir = ml_predict_direction(symbol)

    # 3. Prepare chart (last 90 days)
    df_chart = df.tail(90).copy()

    # Handle multi-index columns safely
    df_chart.columns = [c[0] if isinstance(c, tuple) else c for c in df_chart.columns]

    # Convert Date column
    df_chart["Date"] = pd.to_datetime(df_chart["Date"], errors="coerce")

    # Drop rows with missing data
    df_chart = df_chart.dropna(subset=["Open", "High", "Low", "Close", "Date"])

    chart_data = {
        "dates": df_chart["Date"].dt.strftime("%Y-%m-%d").values.tolist(),
        "open": df_chart["Open"].round(2).values.tolist(),
        "high": df_chart["High"].round(2).values.tolist(),
        "low": df_chart["Low"].round(2).values.tolist(),
        "close": df_chart["Close"].round(2).values.tolist(),
    }

    # 4. Latest price + % change
    latest_price = float(df["Close"].iloc[-1])
    prev_price = float(df["Close"].iloc[-2]) if len(df) >= 2 else latest_price

    change = latest_price - prev_price
    change_pct = (change / prev_price * 100) if prev_price != 0 else 0

    return jsonify({
        "symbol": symbol.upper(),
        "trend_prediction": trend,
        "ml_prediction": ml_dir,
        "latest_price": round(latest_price, 2),
        "change": round(change, 2),
        "change_pct": round(change_pct, 2),
        "chart": chart_data
    })


@app.route("/price", methods=["POST"])
def price():
    """Live price update every few seconds"""

    data = request.get_json()
    symbol = data.get("symbol", "").strip()

    if not symbol:
        return jsonify({"error": "No symbol provided"}), 400

    df = fetch_data(symbol, period="5d", interval="1m")
    if df is None or df.empty or len(df) < 2:
        return jsonify({"error": "No intraday data"}), 400

    latest_price = float(df["Close"].iloc[-1])
    prev_price = float(df["Close"].iloc[-2])

    change = latest_price - prev_price
    change_pct = (change / prev_price * 100) if prev_price != 0 else 0

    return jsonify({
        "symbol": symbol.upper(),
        "latest_price": round(latest_price, 2),
        "change": round(change, 2),
        "change_pct": round(change_pct, 2),
    })


if __name__ == "__main__":
    app.run(debug=True)
