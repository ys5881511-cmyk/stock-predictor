# yash-stockpredictor

Flask + ML stock prediction dashboard.

- Auto fetches stock data via yfinance
- Shows candlestick chart (Plotly in frontend)
- Trend prediction via SMA 20/50
- ML prediction via RandomForest (next-day direction)
- Live price auto-refresh
